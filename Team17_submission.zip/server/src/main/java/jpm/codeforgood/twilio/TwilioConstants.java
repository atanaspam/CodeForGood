package jpm.codeforgood.twilio;

public class TwilioConstants {
	public static final String ACCOUNT_SID = "ACe161139e98191642bff33abb9cfd27c1";
	public static final String AUTH_TOKEN = "abde7904f981b441ff9a82bec40d684b";
	public static final String FROM_NUMBER = "+441212852754";	
}
