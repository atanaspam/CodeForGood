package jpm.codeforgood.util;

public final class Constants {

	private Constants() {
		throw new AssertionError();
	}

}
